<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LaporanBank extends Model
{
    protected $guarded = [];
    protected $table = 'laporan_banks';
}
