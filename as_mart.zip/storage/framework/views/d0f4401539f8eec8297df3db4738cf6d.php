
<?php $__env->startSection('penjualanActive', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12 fs-1 fw-3">
                Detail Transaksi Penjualan #<?php echo e($penjualan->id); ?>

            </div>
        </div>

        <div class="col">
            <?php echo $__env->make('partials.danger', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('partials.success', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex col mr-0  justify-content-end">
                <a href="<?php echo e(route('penjualan.index')); ?>" class="btn btn-primary">Kembali</a>
            </div>
        </div>

        <div class="col mt-4">
            <table class="table table-bordered table-primary text-center">
                <thead>
                    <tr>
                        <th scope="col">Nama Item</th>
                        <th scope="col">Jumlah Item</th>
                        <th scope="col">Harga Satuan</th>
                        <th scope="col">Sub Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $totalHarga = 0; ?>
                    
                    <tr class="table">
                        <?php $__currentLoopData = $penjualan->penjualanDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $subtotal = $detail->total_harga;
                                                $totalHarga += $subtotal;
                                            ?>
                                        <tr class="table">
                                            <td><?php echo e($detail->item->nama); ?></td>
                                            <td>
                                                <?php if($detail->jumlah_dus): ?> <strong><?php echo e($detail->jumlah_dus); ?> dus</strong><br> <?php endif; ?>
                                                <?php if($detail->jumlah_rcg): ?> <strong><?php echo e($detail->jumlah_rcg); ?> renceng</strong><br> <?php endif; ?>
                                                <?php if($detail->jumlah_pcs): ?> <strong><?php echo e($detail->jumlah_pcs); ?> pcs</strong> <?php endif; ?>
                                            </td>
                                            <td><?php echo e('Rp ' . number_format($detail->harga_satuan, 0, ',', '.')); ?></td>
                                            <td><?php echo e('Rp ' . number_format(($detail->jumlah_dus * $detail->item->dus_in_pcs * $detail->harga_satuan) + ($detail->jumlah_rcg * $detail->item->rcg_in_pcs * $detail->harga_satuan) + (($detail->jumlah_pcs * $detail->harga_satuan)), 0, ',', '.')); ?>

                                            </td>
                                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr class="table">
                        <td colspan="3">Total Harga</td>
                        <td><strong><?php echo e('Rp ' . number_format($penjualan->total_harga_akhir, 0, ',', '.')); ?></strong></td>


                    </tr>
                </tbody>
            </table>
        </div>

    </div>

    <style>
        .table {
            border-radius: 8px;
            overflow: hidden;
        }

        .table th {
            background: #0056b3 !important;
            color: white;
        }

        .table tbody tr:hover {
            background: rgba(0, 86, 179, 0.1);
        }

        /* Styling untuk Card dan Tombol */
        .btn-primary {
            border-radius: 5px;
            transition: all 0.2s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #0056b3 !important;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/penjualan/show.blade.php ENDPATH**/ ?>