
<?php $__env->startSection('itemActive', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12 fs-1 fw-3">
                Persediaan Item
            </div>
        </div>
        <hr>
        <div class="col">
            <?php echo $__env->make('partials.danger', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('partials.success', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="d-flex col mr-0  justify-content-end">
                <a href="<?php echo e(route('item.create')); ?>" class="btn btn-success">Tambah Item</a>
            </div>
        </div>

        <div class="col mt-4">
            <table class="table table-bordered table-primary ">
                <thead>
                    <tr>
                        <th scope="col" class="text-center">Nama</th>
                        <th scope="col" class="text-center">Merk</th>
                        
                        <th scope="col" class="text-center">Harga Jual</th>
                        
                        <th scope="col" class="text-center">Stock</th>
                        <th scope="col" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->count()): ?>
                            <tr class="table align-middle">
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->merek); ?></td>
                                
                                <td><?php echo e($item->harga_jual); ?></td>
                                
                                <td> <?php if($item->stock_dus): ?> <strong><?php echo e($item->stock_dus); ?> dus</strong><br> <?php endif; ?>
                                    <?php if($item->stock_rcg): ?> <strong><?php echo e($item->stock_rcg); ?> renceng</strong><br> <?php endif; ?>
                                    <?php if($item->stock_pcs): ?> <strong><?php echo e($item->stock_pcs); ?> pcs</strong> <?php endif; ?>
                                </td>
                                <td>
                                    <div class="dropdown d-flex justify-content-center">
                                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                            id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                            Action
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <li><a class="dropdown-item" href="<?php echo e(route('item.edit', $item->id)); ?>">Edit</a>
                                            </li>
                                            <li>
                                                <form onclick="confirm('are you sure?')"
                                                    action="<?php echo e(route('item.destroy', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item">Delete</a>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr class="table-secondary">
                                <td colspan="6">Tidak ada item tersedia.</td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex justify-content-end">
            <?php echo e($items->links()); ?>

        </div>

        <style>
            .table {
                border-radius: 8px;
                overflow: hidden;
            }

            .table th {
                background: #0056b3 !important;
                color: white;
            }

            .table tbody tr:hover {
                background: rgba(0, 86, 179, 0.1);
            }

            /* Styling untuk Card dan Tombol */
            .btn-primary {
                border-radius: 5px;
                transition: all 0.2s ease-in-out;
            }

            .btn-primary:hover {
                background-color: #0056b3 !important;
            }

            /* Styling Modal */
            .modal-content {
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            }

            .modal-header {
                background-color: #007bff !important;
                color: white;
            }

            .table {
                overflow: visible !important;
            }
        </style>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/item/index.blade.php ENDPATH**/ ?>