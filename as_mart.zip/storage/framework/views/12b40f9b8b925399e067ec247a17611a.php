

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <br>
        <div class="text-start mb-3">
            
        </div>
        <br>
        <h2 class="text-center">LAPORAN HISTORI STOK ITEM</h2>

        <div class="mb-3 text-center">
            <form action="<?php echo e(route('laporan.item')); ?>" method="GET" class="mb-4">
                <div class="row justify-content-center align-items-end">
                    <div class="col-auto">
                        
                        <input type="date" name="tanggal" class="form-control"
                            value="<?php echo e(request('tanggal', now()->toDateString())); ?>">
                    </div>
                    <div class="col-auto mt-4">
                        <button type="submit" class="btn btn-primary">Terapkan Filter</button>
                    </div>
                </div>
            </form>
        </div>

        <hr>
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr>
                        <th>TANGGAL</th>
                        <th>NAMA ITEM</th>
                        
                        
                        <th>JUMLAH PEMBELIAN</th>
                        <th>JUMLAH PENJUALAN</th>
                        <th>SISA STOK (PCS)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d['tanggal']); ?></td>
                            <td><?php echo e($d['nama']); ?></td>
                            
                            
                            <td><?php echo e($d['pembelian']); ?></td>
                            <td><?php echo e($d['penjualan']); ?></td>
                            <td><?php echo e($d['sisa_stok']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/laporan/item.blade.php ENDPATH**/ ?>