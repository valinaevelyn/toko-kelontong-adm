

<h1>Item Created</h1>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/item/created.blade.php ENDPATH**/ ?>