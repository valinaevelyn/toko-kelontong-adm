<?php if($message = Session::get('danger')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e($message); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/partials/danger.blade.php ENDPATH**/ ?>