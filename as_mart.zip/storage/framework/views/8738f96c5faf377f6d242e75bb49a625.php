

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <br>
        <div class="text-start mb-3">
            
        </div>
        <br>
        <h2 class="text-center">LAPORAN UTANG</h2>

        <div class="mb-3 mt-3 text-center">
            <form action="<?php echo e(route('laporan.utang')); ?>" method="GET" class="d-inline-block">
                <div class="row justify-content-center align-items-end">
                    <div class="col-auto">
                        <label for="bulan" class="form-label">PERIODE BULAN</label>
                        <select name="bulan" class="form-select" required>
                            <option value="ALL" <?php echo e(request('bulan') == 'ALL' ? 'selected' : ''); ?>>ALL</option>
                            <?php for($i = 0; $i < 12; $i++): ?>
                                                    <?php
                                                        $date = now()->startOfYear()->addMonths($i);
                                                        $value = $date->format('Y-m');
                                                        $label = $date->translatedFormat('F Y');
                                                    ?>
                                                    <option value="<?php echo e($value); ?>" <?php echo e(request('bulan') == $value ? 'selected' : ''); ?>>
                                                        <?php echo e($label); ?>

                                                    </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div class="col-auto">
                        <label for="tanggal" class="form-label">FILTER TANGGAL (Opsional)</label>
                        <input type="date" name="tanggal" class="form-control" value="<?php echo e(request('tanggal')); ?>">
                    </div>

                    <div class="col-auto mt-4">
                        <button type="submit" class="btn btn-primary">Terapkan Filter</button>
                    </div>
                </div>
            </form>
        </div>

        <hr>

        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="table-dark">
                    <tr>
                        <th>TANGGAL</th>
                        <th>NAMA</th>
                        <th>KETERANGAN</th>
                        <th>UTANG</th>
                        <th>TANGGAL JATUH TEMPO</th>
                        <th>STATUS TERLAMBAT (Hari)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $laporanUtang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->tanggal); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                            <td><?php echo e('Rp ' . number_format($item->jumlah_utang, 0, ',', '.')); ?></td>
                            <td><?php echo e($item->jatuh_tempo); ?></td>
                            <td>
                                <?php if($item->status_terlambat === 'Belum jatuh tempo'): ?>
                                    <?php echo e($item->status_terlambat); ?>

                                <?php elseif($item->status_terlambat === 'Sudah lunas'): ?>
                                    <?php echo e($item->status_terlambat); ?>

                                <?php else: ?>
                                    <?php echo e($item->status_terlambat); ?> Hari Terlambat
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Input Utang -->
    <div class="modal fade" id="inputUtangModal" tabindex="-1" aria-labelledby="inputUtangModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inputUtangModalLabel">Input Utang</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('laporan.utang.biaya')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Form fields for utang -->
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\PPTI\FREELANCE\toko-kelontong\resources\views/laporan/utang.blade.php ENDPATH**/ ?>